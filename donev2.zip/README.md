# Assignment 2: Tokenization, Word Embeddings, and Vector Algebra

You can reuse the conda environment you created for HW1 (or create a new one).
```
conda activate ugrad-nlp
pip install -r requirements.txt
jupyter lab
```
